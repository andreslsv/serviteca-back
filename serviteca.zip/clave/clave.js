module.exports = {
    llave: "sgsstBoxMediaApiJwtToken*",
    llaveRefresh: "sgsstBoxMediaApiJwtRefreshToken*",
}